package com.example.cadastrodeusurio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val botaoSalvar = findViewById<Button>(R.id.botao_salvar)
        botaoSalvar.setOnClickListener {onClickSalvar() }

    }

    fun onClickSalvar(){
        val campoCPF = findViewById<EditText>(R.id.campo_cpf)
        val campoUsuario = findViewById<EditText>(R.id.campo_usuario)
        val campoSenha = findViewById<EditText>(R.id.campo_senha)
        val campoCsenha = findViewById<EditText>(R.id.campo_csenha)

        val valorUsuario = campoUsuario.text.toString()
        val valorCPF = campoCPF.text.toString()
        val valorSenha = campoSenha.text.toString()
        val valorcSenha = campoCsenha.text.toString()

        Toast.makeText(this, "$valorUsuario : $valorSenha: $valorCPF: $valorcSenha", Toast.LENGTH_LONG).show()





    }

}
