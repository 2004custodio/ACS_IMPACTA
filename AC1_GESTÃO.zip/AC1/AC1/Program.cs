﻿using System;

namespace AC1
{
    class Program
    {
        static void Main(string[] args)
        {

            Calculadora c = new Calculadora();
            Console.WriteLine("Numero:");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("Numero:");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Operacao = + * - / :");
            string operacao = Console.ReadLine();
            if(operacao == "+"){
                c.Soma(a, b);
            }
            else if(operacao == "*")
            {
                c.Multiplicacao(a, b);
            }
            if(operacao == "/")
            {
                c.Divisao(a, b);
            }
            else if(operacao == "-")
            {
                c.Subtracao(a, b);
            }
            Console.WriteLine("Total = " + c);

            Console.ReadKey();
        }
    }
}
