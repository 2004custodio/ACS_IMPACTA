﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;

namespace AC1
{
    class Calculadora
    {
        double total;
        public double Soma(double a , double b)
        {
            return total = a + b;
        }

        public double Multiplicacao(double a  , double b)
        {
            return total = a * b;
        }

        public double Divisao(double a , double b)
        {
            return total = a / b;
        }

        public double Subtracao(double a, double  b)
        {
            return total =  a - b;
        }

        public override string ToString()
        {
            return total.ToString("F2",CultureInfo.InvariantCulture);
        }
    }
}
